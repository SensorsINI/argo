*PADS-LIBRARY-PART-TYPES-V9*

30R500UF 30R500UF I FUS 7 1 0 0 0
TIMESTAMP 2025.05.18.15.04.39
"Mouser Part Number" 576-30R500UF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Littelfuse/30R500UF?qs=PWhpLWeW8weNzTL9%2FrjiGQ%3D%3D
"Manufacturer_Name" LITTELFUSE
"Manufacturer_Part_Number" 30R500UF
"Description" PTC 30V POLYFUSE  RADIAL LEADS 5A
"Datasheet Link" https://m.littelfuse.com/~/media/electronics/datasheets/resettable_ptcs/littelfuse_ptc_30r_datasheet.pdf.pdf
"Geometry.Height" 25.6mm
GATE 1 2 0
30R500UF
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
927166/1680568/2.50/2/4/Fuse
